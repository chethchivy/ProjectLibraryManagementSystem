﻿-- Functions 
--  Function For Book Table
CREATE FUNCTION fnSearchBookByBookTitle(@bt nvarchar(255))
RETURNS TABLE 
AS
RETURN(
	SELECT * FROM tbBook 
	WHERE LOWER(CAST(BookCode AS NVARCHAR)) = LOWER(@bt)
        OR @bt IS NULL 
        OR LOWER(BookTitle) LIKE '%' + LOWER(@bt) + '%'
)
Go

CREATE FUNCTION fnSearchBookByID(@bc int)
RETURNS TABLE 
AS
RETURN(
	SELECT * FROM tbBook WHERE BookCode = @bc
)
Go

CREATE FUNCTION fnGetLateFeeByBookCode
(
    @BookCode INT
)
RETURNS MONEY
AS
BEGIN
    DECLARE @LateFee MONEY;

    SELECT @LateFee = LateFee
    FROM tbBook
    WHERE BookCode = @BookCode;

    RETURN @LateFee;
END
GO
CREATE FUNCTION fnPriceByBookCode
(
    @BookCode INT
)
RETURNS MONEY
AS
BEGIN
    DECLARE @Price MONEY;

    SELECT @Price = Price
    FROM tbBook
    WHERE BookCode = @BookCode;

    RETURN @Price;
END
GO

-- Supplier 
CREATE FUNCTION fnSearchSupplier(@search nvarchar(100))
RETURNS TABLE 
AS
RETURN(
	SELECT * FROM tbSupplier 
	WHERE LOWER(CAST(SupplierID AS NVARCHAR)) = LOWER(@search)
       OR @search IS NULL OR LOWER(SupplierName) LIKE '%' + LOWER(@search) + '%'
)
Go 

CREATE FUNCTION fnSearchSupplierNameByID(@SupplierID tinyint)
RETURNS TABLE 
AS
RETURN(
	SELECT SupplierID, SupplierName FROM tbSupplier 
	WHERE SupplierID = @SupplierID OR @SupplierID IS NULL 
)
Go 

-- Function For Staff Table
CREATE FUNCTION fnSearchStaffByID(@sid varchar(10))
RETURNS TABLE 
AS
RETURN(
	SELECT * FROM tbStaff WHERE LOWER(CAST(StaffID AS VARCHAR)) LIKE '%' +  LOWER(@sid) + '%'
)
Go

CREATE FUNCTION fnSearchStaffByName(@sn nvarchar(100))
RETURNS TABLE 
AS
RETURN(
	SELECT * FROM tbStaff 
	WHERE @sn IS NULL OR (FirstName + ' ' + LastName) LIKE N'%' + @sn+ '%'
)
Go

CREATE FUNCTION fnSearchStaffs(@search nvarchar(100))
RETURNS TABLE 
AS
RETURN(
	SELECT * FROM tbStaff 
	WHERE LOWER(CAST(StaffID AS NVARCHAR)) = LOWER(@search)
       OR @search IS NULL OR LOWER((FirstName + ' ' + LastName)) LIKE '%' + LOWER(@search) + '%'
)
Go

-- Member
CREATE FUNCTION fnSearchMember(@search nvarchar(100))
RETURNS TABLE 
AS
RETURN(
	SELECT MemberID,  (FirstName + ' ' + LastName) AS MemberName FROM tbMember 
	WHERE LOWER(CAST(MemberID AS NVARCHAR)) = LOWER(@search)
        OR @search IS NULL 
        OR LOWER(FirstName + ' ' + LastName) LIKE '%' + LOWER(@search) + '%'
)
Go
CREATE FUNCTION fnSearchMembers(@search nvarchar(100))
RETURNS TABLE 
AS
RETURN(
	SELECT * FROM tbMember 
	WHERE LOWER(CAST(MemberID AS NVARCHAR)) = LOWER(@search)
        OR @search IS NULL 
        OR LOWER(FirstName + ' ' + LastName) LIKE '%' + LOWER(@search) + '%'
)
Go

-- User
CREATE FUNCTION fnSearchUsers(@search nvarchar(20))
RETURNS TABLE 
AS
RETURN(
	SELECT * FROM tbUser 
	WHERE LOWER(CAST(UserID AS NVARCHAR)) = LOWER(@search)
        OR @search IS NULL 
        OR LOWER(UserName) LIKE '%' + LOWER(@search) + '%'
)
Go

CREATE FUNCTION fnSearchUser(@search nvarchar(20))
RETURNS TABLE 
AS
RETURN(
	SELECT UserID, UserName FROM tbUser 
	WHERE LOWER(CAST(UserID AS NVARCHAR)) = LOWER(@search)
        OR @search IS NULL 
        OR LOWER(UserName) LIKE '%' + LOWER(@search) + '%'
)
Go

-- Borrow
CREATE FUNCTION fnSearchBorrowByBorrowID(@BorrowID int)
RETURNS TABLE
AS
RETURN
(
    SELECT 
        b.BorrowID,
        b.BorrowDate,
        b.MemberID,
        b.MemberName,
        b.StaffID,
        b.StaffName,
        b.StaffPosition,
		bd.BookCode,
		bd.BookTitle,
		bd.DueDate
    FROM 
        tbBorrow b
    JOIN 
        tbBorrowDetail bd ON b.BorrowID = bd.BorrowID
    WHERE 
        b.BorrowID = @BorrowID
);
Go

CREATE FUNCTION fnGetBorrowByMemberID
(
    @MemberID INT
)
RETURNS TABLE
AS
RETURN
(
    SELECT DISTINCT bd.BorrowID, bd.BookCode, bd.BookTitle
    FROM tbBorrowDetail bd
    INNER JOIN tbBorrow b ON bd.BorrowID = b.BorrowID
    WHERE b.MemberID = @MemberID
);
Go

CREATE FUNCTION fnGetBorrowByMemberIDFromBE
(
    @MemberID INT
)
RETURNS TABLE
AS
RETURN
(
    SELECT DISTINCT be.BorrowID, be.BookTitle
    FROM tbBorrowExpire be
    INNER JOIN tbBorrow b ON be.BorrowID = b.BorrowID
    WHERE b.MemberID = @MemberID
);
Go

CREATE FUNCTION fnGetBorrowIDByBookCode
(
    @BookCode INT
)
RETURNS TABLE
AS
RETURN
(
    SELECT BorrowID FROM tbBorrowDetail  WHERE BookCode = @BookCode
);
Go

CREATE FUNCTION fnGetBookByBorrowID
(
    @BorrowID INT
)
RETURNS TABLE
AS
RETURN
(
    SELECT BookCode, BookTitle FROM tbBorrowDetail  WHERE BorrowID = @BorrowID
);
Go

CREATE FUNCTION fnGetBorrowAndDueDateByBorrowID
(
    @BorrowID INT,
	@BookCode INT
)
RETURNS TABLE
AS
RETURN
(
    SELECT BorrowDate, DueDate FROM tbBorrowDetail 
    WHERE BorrowID = @BorrowID AND BookCode = @BookCode
);
Go

CREATE FUNCTION fnGetBorrowedBookByMemberID
(
	@MemberID INT
)
RETURNS TINYINT
AS
BEGIN
    DECLARE @BookCount TINYINT;

    SELECT @BookCount = COUNT(*) FROM tbBorrowDetail bd JOIN tbBorrow b ON bd.BorrowID = b.BorrowID WHERE b.MemberID = @MemberID

    RETURN @BookCount;
END
GO

-- Renew
CREATE FUNCTION fnGetRenewByID
(
    @RenewID INT
)
RETURNS TABLE
AS
RETURN
(
    SELECT * FROM tbRenew WHERE RenewID = @RenewID
);
GO

CREATE FUNCTION fnRenewReport
(
    @bd DATE, @ed DATE
)
RETURNS TABLE
AS
RETURN
(
    SELECT RenewID, RenewDate, NewDueDate, BookCode, MemberName, StaffName, StaffPosition FROM tbRenew WHERE RenewDate between @bd AND @ed
);
GO
select * from fnRenewReport('2024-06-06', '2024-06-24');
-- BorrowExpire
CREATE FUNCTION fnSearchBorrowExpier(@search int)
RETURNS TABLE 
AS
RETURN(
	SELECT * FROM tbBorrowExpire 
	WHERE CAST(BorrowExpireID AS NVARCHAR) = @search OR MemberID = @search
       OR @search IS NULL OR LOWER(BookTitle) LIKE '%' + LOWER(@search) + '%'
)
Go
CREATE FUNCTION fnSearchByMemberID
(
    @MemberID INT
)
RETURNS TABLE
AS
RETURN
(
    SELECT *
    FROM tbBorrowExpire
    WHERE MemberID = @MemberID
);
Go

-- Card
CREATE FUNCTION fnSearchCards(@search nvarchar(100))
RETURNS TABLE 
AS
RETURN(
	SELECT * FROM tbCard 
	WHERE CAST(CardID AS NVARCHAR) = @search
       OR @search IS NULL OR LOWER(MemberName) LIKE '%' + LOWER(@search) + '%'
)
Go

CREATE FUNCTION fnSearchUser(@search nvarchar(100))
RETURNS TABLE 
AS
RETURN(
	SELECT CardID, MemberName FROM tbCard 
	WHERE LOWER(CAST(CardID AS NVARCHAR)) = LOWER(@search)
        OR @search IS NULL 
        OR LOWER(MemberName) LIKE '%' + LOWER(@search) + '%'
)
Go
-- Import 
CREATE FUNCTION fnSearchImportByImportID(@ImportID int)
RETURNS TABLE
AS
RETURN
(
    SELECT 
        i.ImportID,
        i.ImportDate,
        i.TotalAmount,
        i.SupplierID,
        i.SupplierName,
        i.StaffID,
        i.StaffName,
        i.StaffPosition,
        id.BookCode,
		id.BookTitle,
        id.ImportQty,
        id.UnitPrice,
        id.Amount
    FROM 
        tbImport i
    JOIN 
        tbImportDetail id ON i.ImportID = id.ImportID
    WHERE 
        i.ImportID = @ImportID
);
Go

CREATE FUNCTION fnSearchImports(@search int)
RETURNS TABLE 
AS
RETURN(
	SELECT * FROM tbImport 
	WHERE ImportID = @search
       OR @search IS NULL 
)
Go

-- ImportDetail
CREATE FUNCTION fnSearchImportDetails(@impID int, @bt int)
RETURNS TABLE 
AS
RETURN(
	SELECT * FROM tbImportDetail
	WHERE ( ImportID = @impID AND BookCode = @bt )
       OR @impID IS NULL 
)
Go

-- Invoice
CREATE FUNCTION fnSearchInvoice(@search int)
RETURNS TABLE 
AS
RETURN(
	SELECT * FROM tbInvoice 
	WHERE CAST(InvoiceNo AS int) = @search OR @search IS NULL 
)
Go

-- BorrowExpire 
CREATE FUNCTION fnSearchBorrowExpire
(
    @searchID int 
)
RETURNS TABLE
AS
RETURN
(
    SELECT *
    FROM tbBorrowExpire
    WHERE 
        (@searchID IS NULL OR BorrowExpireID = @searchID OR MemberID = @searchID)
);
GO
CREATE FUNCTION fnBorrowExpireReport
(
    @bd DATE, @ed DATE
)
RETURNS TABLE
AS
RETURN
(
    SELECT * FROM tbBorrowExpire WHERE ExpiredDate between @bd AND @ed
);
GO

-- Payment
CREATE FUNCTION fnSearchPayment(@search int)
RETURNS TABLE 
AS
RETURN(
	SELECT * FROM tbPayment 
	WHERE CAST(PaymentNo AS int) = @search OR @search IS NULL 
)
Go

-- Return
CREATE FUNCTION fnSearchReturnByReturnID(@ReturnID int)
RETURNS TABLE
AS
RETURN
(
    SELECT 
        r.ReturnID,
        r.ReturnDate,
        r.MemberID,
        r.MemberName,
        r.StaffID,
        r.StaffName,
        r.StaffPosition,
		rd.BorrowID,
        rd.BookCode, 
		rd.BookTitle,
        rd.BorrowDate,
        rd.DueDate,
        rd.Ripped,
        rd.FineAmount
    FROM 
        tbReturn r
    JOIN 
        tbReturnDetail rd ON r.ReturnID = rd.ReturnID
    WHERE 
        r.ReturnID = @ReturnID
);
Go

CREATE FUNCTION fnGetTotalFineAmount (@ReturnID INT)
RETURNS MONEY
AS
BEGIN
    DECLARE @TotalFine MONEY;
    
    SELECT @TotalFine = SUM(FineAmount)
    FROM tbReturnDetail
    WHERE ReturnID = @ReturnID;
    
    RETURN @TotalFine;
END
GO

select * from fnSearchReturnByReturnID(1012)
select * from tbReturnDetail
select * from tbInvoice
select * from tbBorrowExpire
delete from tbBorrow where BorrowID = 2008