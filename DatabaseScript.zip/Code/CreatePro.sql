﻿-- Table Book 
USE dbLibraryManagement;
Go

CREATE PROCEDURE spInsertBook
		@BookTitle NVARCHAR(255),
		@Genres NVARCHAR(50),
		@Author NVARCHAR(50),
		@PublishYear SMALLINT,
		@BookQty TINYINT,
		@LateFee MONEY,
		@Price MONEY,
		@OutputMessage NVARCHAR(255) OUTPUT
AS
BEGIN
	SET NOCOUNT ON;
    IF NOT EXISTS (
        SELECT 1
        FROM tbBook
        WHERE BookTitle = @BookTitle
          AND Author = @Author
          AND PublishYear = @PublishYear
    )
    BEGIN
        INSERT INTO tbBook (BookTitle, Genres, Author, PublishYear, BookQty, LateFee, Price)
        VALUES (@BookTitle, @Genres, @Author, @PublishYear, @BookQty, @LateFee, @Price);
        
        SET @OutputMessage = 'Book inserted successfully.';
    END
    ELSE
    BEGIN
        SET @OutputMessage = 'Duplicate book entry found. Book not inserted.';
    END
END;
Go

CREATE PROCEDURE spUpdateBookByBookCode
		@BookCode INT,
		@BookTitle NVARCHAR(255),
		@Genres NVARCHAR(50),
		@Author NVARCHAR(50),
		@PublishYear SMALLINT,
		@BookQty TINYINT,
		@LateFee MONEY,
		@Price MONEY,
		@OutputMessage NVARCHAR(255) OUTPUT
AS
BEGIN
    BEGIN TRY
        IF EXISTS (SELECT 1 FROM tbBook WHERE BookCode = @BookCode)
        BEGIN
            UPDATE tbBook
            SET
                BookTitle = @BookTitle,
                Genres = @Genres,
                Author = @Author,
                PublishYear = @PublishYear,
                BookQty = @BookQty,
                LateFee = @LateFee,
                Price = @Price
            WHERE BookCode = @BookCode;
			SET @OutputMessage = 'Book updated successfully.';
        END
        ELSE
        BEGIN
            SET @OutputMessage = 'Book not found.';
        END
    END TRY
    BEGIN CATCH
        SET @OutputMessage = ERROR_MESSAGE();
    END CATCH
END;
Go

CREATE PROCEDURE spHandleBookExpiration
    @BorrowID int,
    @BookCode int,
    @ExpiredDate date
AS
BEGIN
	SET NOCOUNT ON;
    -- Insert the expired book into tbBorrowExpire
    INSERT INTO tbBorrowExpire (ExpiredDate, BorrowID, MemberID, BookTitle)
    SELECT @ExpiredDate,  bd.BorrowID, b.MemberID, bd.BookTitle
    FROM tbBorrowDetail bd
    JOIN tbBorrow b ON bd.BorrowID = b.BorrowID
    WHERE bd.BorrowID = @BorrowID AND bd.BookCode = @BookCode;

    -- Delete the expired book from tbBorrowDetail
    DELETE FROM tbBorrowDetail
    WHERE BorrowID = @BorrowID AND BookCode = @BookCode;

    -- Optional: Clean up tbBorrow if no more books are associated with that BorrowID
    IF NOT EXISTS (SELECT 1 FROM tbBorrowDetail WHERE BorrowID = @BorrowID)
    BEGIN
        DELETE FROM tbBorrow WHERE BorrowID = @BorrowID;
    END
END
GO
CREATE PROCEDURE spAddStockQty @BookCode INT
AS
BEGIN
	UPDATE tbBook
		SET BookQty = BookQty + 1
		WHERE BookCode = @BookCode;
END;
Go

CREATE PROCEDURE spRemoveStockQty @BookCode INT
AS
BEGIN
	UPDATE tbBook
		SET BookQty = BookQty - 1
		WHERE BookCode = @BookCode;
END;
Go

-- Supplier Table
CREATE PROCEDURE spInsertSupplier (
  @SupplierName nvarchar(100),
  @SupplierAddress nvarchar(255),
  @PhoneNumber1 nvarchar(20),
  @PhoneNumber2 nvarchar(20),
  @OutputMessage bit OUTPUT
)
AS
BEGIN
	IF NOT EXISTS (
        SELECT 1
        FROM tbSupplier
        WHERE SupplierName = @SupplierName
			AND SupplierAddress = @SupplierAddress
			AND (PhoneNumber1 = @PhoneNumber1
			OR PhoneNumber2 = @PhoneNumber2)
    )
    BEGIN
        INSERT INTO tbSupplier (SupplierName, SupplierAddress, PhoneNumber1, PhoneNumber2)
    VALUES (@SupplierName, @SupplierAddress, @PhoneNumber1, @PhoneNumber2);
	SET @OutputMessage = 1;
    END
    ELSE
    BEGIN
        SET @OutputMessage = 0
    END 
END;
Go

CREATE PROCEDURE spUpdateSupplierByID (
  @SupplierID tinyint,
  @SupplierName nvarchar(100),
  @SupplierAddress nvarchar(255),
  @PhoneNumber1 nvarchar(20),
  @PhoneNumber2 nvarchar(20),
  @OutputMessage nvarchar(255) OUTPUT
)
AS
BEGIN
	BEGIN TRY
        IF EXISTS (SELECT 1 FROM tbSupplier WHERE SupplierID = @SupplierID)
        BEGIN
            UPDATE tbSupplier
			SET SupplierName = @SupplierName,
				  SupplierAddress = @SupplierAddress,
				  PhoneNumber1 = @PhoneNumber1,
				  PhoneNumber2 = @PhoneNumber2
			  WHERE SupplierID = @SupplierID;
			--SET @OutputMessage = 'Supplier updated successfully.';
        END
       /* ELSE
        BEGIN
            SET @OutputMessage = 'Supplier was not found.';
        END */
    END TRY
    BEGIN CATCH
        SET @OutputMessage = ERROR_MESSAGE();
    END CATCH
END;
Go

-- Staff Table
CREATE PROCEDURE spInsertStaff(
	@sfn NVARCHAR(50),
	@sln NVARCHAR(50),
	@ss NCHAR(1),
	@sbd DATE,
	@sp NVARCHAR(50),
	@hn NVARCHAR(15) = NULL,
	@StrNo NVARCHAR(25) = NULL,
	@Sangkat NVARCHAR(50),
	@Khann NVARCHAR(15),
	@Province NVARCHAR(25),
	@ContactNumber NVARCHAR(20) = NULL,
	@PersonalNumber NVARCHAR(20),
	@Salary MONEY,
	@HiredDate DATE,
	@Photo VARBINARY(max) = NULL,
	@StopWork BIT = NULL,
	@isSuccess Bit OUTPUT
)
AS
BEGIN
	IF NOT EXISTS (
        SELECT 1 
        FROM tbStaff 
        WHERE FirstName = @sfn
        AND LastName = @sln
        AND PersonalNumber = @PersonalNumber
    )
		BEGIN
			INSERT INTO tbStaff (FirstName, LastName, Sex, BirthDate, StaffPosition, HouseNo, StreetNo, Sangkat, Khann, Province, ContactNumber, PersonalNumber, Salary, HireDate, Photo, StopWork)
			VALUES (@sfn, @sln, @ss, @sbd, @sp, @hn, @StrNo, @Sangkat, @Khann, @Province, @ContactNumber, @PersonalNumber, @Salary, @HiredDate, @Photo, @StopWork);
			SET @isSuccess = 1;
		END
    ELSE
		BEGIN
			SET @isSuccess = 0;
		END
END;
Go

CREATE PROCEDURE spUpdateStaffByID(
	@sID SMALLINT,
	@sfn NVARCHAR(50),
	@sln NVARCHAR(50),
	@ss NCHAR(1),
	@sbd DATE,
	@sp NVARCHAR(50),
	@hn NVARCHAR(15) = NULL,
	@StrNo NVARCHAR(25) = NULL,
	@Sangkat NVARCHAR(50),
	@Khann NVARCHAR(15),
	@Province NVARCHAR(25),
	@ContactNumber NVARCHAR(20) = NULL,
	@PersonalNumber NVARCHAR(20),
	@Salary MONEY,
	@HiredDate DATE,
	@Photo VARBINARY(max) = NULL,
	@StopWork BIT = NULL,
	@isSuccess Bit OUTPUT
)
AS
BEGIN
	BEGIN TRANSACTION
		IF EXISTS (
		SELECT 1 
		FROM tbStaff 
		WHERE (FirstName = @sfn AND LastName = @sln AND PersonalNumber = @PersonalNumber) AND StaffID <> @sID
	)
	BEGIN
		ROLLBACK TRANSACTION
		SET @isSuccess = 0;
		RAISERROR ('A staff with the same phone number or with the same name and birth date already exists.', 16, 1)
		RETURN
	END
	UPDATE tbStaff
	SET 
		FirstName = @sfn,
		LastName = @sln,
		Sex = @ss,
		BirthDate = @sbd,
		StaffPosition = @sp,
		HouseNo = @hn,
		StreetNo = @StrNo,
		Sangkat = @Sangkat,
		Khann = @Khann,
		Province = @Province,
		ContactNumber = @ContactNumber,
		PersonalNumber = @PersonalNumber,
		HireDate = @HiredDate,
		Salary = @Salary,
		Photo = @Photo,
		StopWork = @StopWork
	WHERE 
		StaffID = @sID
		SET @isSuccess = 1;
	COMMIT TRANSACTION
END
GO

-- Member Table
CREATE PROCEDURE spInsertMember
    @FirstName NVARCHAR(50),
    @LastName NVARCHAR(50),
    @Sex NCHAR(6),
    @BirthDate DATE,
    @Sangkat NVARCHAR(50),
    @Khann NVARCHAR(50),
    @Province NVARCHAR(50),
    @PhoneNumber NVARCHAR(50),
	@Photo VARBINARY(max),
	@OutputMessage BIT OUTPUT
AS
BEGIN
    BEGIN TRANSACTION
    IF EXISTS (
        SELECT 1 
        FROM tbMember 
        WHERE PhoneNumber = @PhoneNumber 
           AND FirstName = @FirstName AND LastName = @LastName AND BirthDate = @BirthDate
    )
    BEGIN
		SET @OutputMessage = 0;
        ROLLBACK TRANSACTION
        RAISERROR ('A member with the same phone number or with the same name and birth date already exists.', 16, 1)
        RETURN
    END
    INSERT INTO tbMember (FirstName, LastName, Sex, BirthDate, Sangkat, Khann, Province, PhoneNumber, Photo)
    VALUES (@FirstName, @LastName, @Sex, @BirthDate, @Sangkat, @Khann, @Province, @PhoneNumber, @Photo)
	SET	@OutputMessage = 1;
    COMMIT TRANSACTION
END
GO

CREATE PROCEDURE spUpdateMember
    @MemberID INT,
    @FirstName NVARCHAR(50),
    @LastName NVARCHAR(50),
    @Sex NCHAR(6),
    @BirthDate DATE,
    @Sangkat NVARCHAR(50),
    @Khann NVARCHAR(50),
    @Province NVARCHAR(50),
    @PhoneNumber NVARCHAR(50),
	@Photo VARBINARY(max),
	@isSuccess BIT OUTPUT
AS
BEGIN
    BEGIN TRANSACTION
    IF EXISTS (
        SELECT 1 
        FROM tbMember 
        WHERE (PhoneNumber = @PhoneNumber AND @FirstName = @FirstName AND LastName = @LastName AND BirthDate = @BirthDate)
          AND MemberID <> @MemberID
    )
    BEGIN
        ROLLBACK TRANSACTION
		SET @isSuccess = 0;
        RAISERROR ('A member with the same phone number or with the same name and birth date already exists.', 16, 1)
        RETURN
    END
    UPDATE tbMember
    SET 
        FirstName = @FirstName,
        LastName = @LastName,
        Sex = @Sex,
        BirthDate = @BirthDate,
        Sangkat = @Sangkat,
        Khann = @Khann,
        Province = @Province,
        PhoneNumber = @PhoneNumber,
		Photo = @Photo
    WHERE 
        MemberID = @MemberID
		SET @isSuccess = 1;
    COMMIT TRANSACTION
END
GO

-- User 
CREATE PROCEDURE spInsertUser(
    @UserName VARCHAR(20),
    @UserPassword VARCHAR(20),
    @StaffID SMALLINT,
	@isSuccess BIT OUTPUT
)
AS
BEGIN
    IF EXISTS (SELECT 1 FROM tbUser WHERE UserName = @UserName)
    BEGIN
		SET @isSuccess = 0;
        RETURN;
    END

    DECLARE @StaffName nvarchar(100),
            @StaffPosition nvarchar(100);

    SELECT @StaffName = CONCAT(FirstName, ' ', LastName),
           @StaffPosition = StaffPosition
    FROM tbStaff
    WHERE StaffID = @StaffID;

    INSERT INTO tbUser (UserName, UserPassword, StaffID, StaffName, StaffPosition)
    VALUES (@UserName, @UserPassword, @StaffID, @StaffName, @StaffPosition);
	
	SET @isSuccess = 1;
END;
Go 

CREATE PROCEDURE spUpdateUserByUserID(
    @UserID int,
	@UserName varchar(20),
    @UserPassword varchar(20),
	@isSuccess BIT OUTPUT
)
AS
BEGIN
    BEGIN TRANSACTION
    IF EXISTS (
        SELECT 1 
        FROM tbUser 
        WHERE (UserName = @UserName AND UserPassword = @UserPassword)
          AND UserID <> @UserID
    )
    BEGIN
	ROLLBACK TRANSACTION
		SET @isSuccess = 0;
        RAISERROR ('A user with the same username same password already exists.', 16, 1)
        RETURN
    END
    -- Update the user information in tbUser
    UPDATE tbUser
    SET UserName = @UserName, 
			UserPassword = COALESCE(@UserPassword, UserPassword)
    WHERE UserID = @UserID;
	SET @isSuccess = 1;
	COMMIT TRANSACTION
END;
Go

-- Card
CREATE PROCEDURE spInsertCard(
    @CreateDate Date,
    @Expire Date,
	@MemberID INT,
    @StaffID SMALLINT,
	@isSuccess BIT OUTPUT
)
AS
BEGIN
    IF EXISTS (SELECT 1 FROM tbCard WHERE MemberID = @MemberID)
    BEGIN
		SET @isSuccess = 0;
        RETURN;
    END

    DECLARE @MemberName nvarchar(100), @StaffName nvarchar(100),
            @StaffPosition nvarchar(100);

	SELECT @MemberName = CONCAT(FirstName, ' ', LastName) FROM tbMember WHERE MemberID = @MemberID;
    SELECT @StaffName = CONCAT(FirstName, ' ', LastName), @StaffPosition = StaffPosition
    FROM tbStaff WHERE StaffID = @StaffID;

    INSERT INTO tbCard (CreateDate, Expire, MemberID, MemberName, StaffID, StaffName, StaffPosition)
    VALUES (@CreateDate, @Expire, @MemberID, @MemberName, @StaffID, @StaffName, @StaffPosition);
	
	SET @isSuccess = 1;
END;
Go 

CREATE PROCEDURE spUpdateCardByID(
    @CardID int,
	@CreateDate Date,
    @Expire Date,
	@isSuccess BIT OUTPUT
)
AS
BEGIN
    BEGIN TRANSACTION
    IF(@Expire < @CreateDate)
    BEGIN
	ROLLBACK TRANSACTION
		SET @isSuccess = 0;
        RAISERROR ('A Expired Date must Bigger than Create Date ', 16, 1)
        RETURN
    END
    -- Update the user information in tbUser
    UPDATE tbCard
    SET CreateDate = @CreateDate, 
			Expire = @Expire
    WHERE CardID = @CardID;
	SET @isSuccess = 1;
	COMMIT TRANSACTION
END;
Go

-- Import Table
CREATE PROCEDURE spInsertImport
	--@TotalAmount Money,
    @SupplierID tinyint,
    @StaffID smallint,
	@OutputMessage bit output,
	@NewImportID int OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
	SET @OutputMessage = 0;
    DECLARE @ImportDate DATE = GETDATE(),
					@BookCode INT,
					@SupplierName nvarchar(100),
					@StaffName nvarchar(100),
					@StaffPosition nvarchar(100)
	
	SELECT @SupplierName = SupplierName From tbSupplier Where SupplierID = @SupplierID;
	SELECT @StaffName = CONCAT(FirstName, ' ', LastName),
				@StaffPosition = StaffPosition
    FROM tbStaff
    WHERE StaffID = @StaffID;
        -- Insert the new import record
        INSERT INTO tbImport (ImportDate, SupplierID, SupplierName, StaffID, StaffName, StaffPosition)
        VALUES (@ImportDate, @SupplierID, @SupplierName, @StaffID, @StaffName, @StaffPosition);
        Set @OutputMessage = 1;
        SET @NewImportID = SCOPE_IDENTITY();
END;
Go

CREATE PROCEDURE spUpdateImport
    @ImportID INT,
	@ImportDate DATE,
    @SupplierID TINYINT,
    @StaffID SMALLINT,
    @isSuccess BIT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @SupplierName NVARCHAR(100),@StaffName NVARCHAR(100),@StaffPosition NVARCHAR(100);
	
    BEGIN TRY
		SELECT @SupplierName = SupplierName FROM vGetSuppliersName WHERE SupplierID = @SupplierID;
		SELECT @StaffName = StaffName, @StaffPosition = StaffPosition FROM vGetStaffIDNamePosition WHERE StaffID = @StaffID;

        UPDATE tbImport
        SET SupplierID = @SupplierID,
            SupplierName = @SupplierName,
            StaffID = @StaffID,
            StaffName = @StaffName,
            StaffPosition = @StaffPosition
        WHERE ImportID = @ImportID;
        SET @isSuccess = 1;
    END TRY
    BEGIN CATCH
        SET @isSuccess = 0;
    END CATCH
END;
GO

-- Import Detail
-- not done
CREATE PROCEDURE spInsertImportDetail
    @ImportID int,
    @BookCode int,
	@BookTitle nvarchar(255),
    @ImportQty tinyint,
    @UnitPrice money,
	@isSuccess BIT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @Amount MONEY;
    SET @Amount = @ImportQty * @UnitPrice;
	--SELECT @BookCode = BookCode FROM tbBook WHERE BookTitle = @BookTitle;

    IF NOT EXISTS (
        SELECT 1
        FROM tbImportDetail
        WHERE ImportID = @ImportID
          AND BookCode = @BookCode
    )
    BEGIN
        IF EXISTS (
            SELECT 1
            FROM tbBook
            WHERE BookCode = @BookCode
        )
        BEGIN
            UPDATE tbBook
            SET BookQty = BookQty + @ImportQty
            WHERE BookCode = @BookCode;
       
            INSERT INTO tbImportDetail (ImportID, BookCode, BookTitle, ImportQty, UnitPrice, Amount)
            VALUES (@ImportID, @BookCode, @BookTitle,  @ImportQty, @UnitPrice, @Amount);
			SET  @isSuccess = 1;
        END
    END
	ELSE
    BEGIN
        SET @isSuccess = 0
    END ;
END;
Go

CREATE PROCEDURE spUpdateImportDetail
    @ImportID INT,
    @BookCode INT,
	@BookTitle NVARCHAR(255),
    @NewImportQty TINYINT,
    @NewUnitPrice MONEY,
    @isSuccess BIT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @OldImportQty TINYINT;
    DECLARE @Amount MONEY;
    DECLARE @OldAmount MONEY;
    SET @isSuccess = 0;

    SET @Amount = @NewImportQty * @NewUnitPrice;

    BEGIN TRY
        -- Check if the record exists in tbImportDetail
        IF EXISTS (
            SELECT 1
            FROM tbImportDetail
            WHERE ImportID = @ImportID
              AND BookCode = @BookCode
        )
        BEGIN
            -- Get the old ImportQty
            SELECT @OldImportQty = ImportQty
            FROM tbImportDetail
            WHERE ImportID = @ImportID
              AND BookCode = @BookCode;

            UPDATE tbBook
            SET BookQty = BookQty - @OldImportQty + @NewImportQty
            WHERE BookCode = @BookCode;

            UPDATE tbImportDetail
            SET BookTitle = @BookTitle,
					ImportQty = @NewImportQty,
                UnitPrice = @NewUnitPrice,
                Amount = @Amount
            WHERE ImportID = @ImportID
              AND BookCode = @BookCode;
            SET @isSuccess = 1;
        END
    END TRY
    BEGIN CATCH
        SET @isSuccess = 0;
    END CATCH
END;
GO

-- Borrow 
CREATE PROCEDURE spUpdateBorrow
    @BorrowID int,
    @BorrowDate date,
    @StaffID smallint,
	@MemberID int,
	@isSuccess bit OUTPUT
AS
BEGIN
	SET NOCOUNT ON;
	SET @isSuccess = 0;
	DECLARE @MemberName nvarchar(100), @StaffName nvarchar(100), @StaffPosition nvarchar(100)
	SELECT @MemberName = MemberName FROM vGetMemberIDName WHERE MemberID = @MemberID;
    SELECT @StaffName = StaffName, @StaffPosition = StaffPosition FROM vGetStaffIDNamePosition WHERE StaffID = @StaffID;
    UPDATE tbBorrow
    SET 
        BorrowDate = @BorrowDate,
		MemberID = @MemberID,
		MemberName = @MemberName,
        StaffID = @StaffID,
        StaffName = @StaffName,
        StaffPosition = @StaffPosition
    WHERE 
        BorrowID = @BorrowID;
		SET @isSuccess = 1;
END
GO

-- BorrowDetail
CREATE PROCEDURE spInsertBorrowDetail
    @BorrowID int,
    @BookCode nvarchar(255),
    @BookTitle nvarchar(255),
    @BorrowDate date,
    @DueDate date,
	@isSuccess BIT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

	SET @isSuccess = 0;
    IF NOT EXISTS ( SELECT 1 FROM tbBorrowDetail WHERE BorrowID = @BorrowID AND BookCode = @BookCode )
    BEGIN
		IF @BorrowDate > GETDATE()
		BEGIN
			RAISERROR('BorrowDate cannot be in the future.', 16, 1);
			RETURN;
		END

		IF @DueDate <= @BorrowDate
		BEGIN
			RAISERROR('DueDate must be greater than BorrowDate.', 16, 1);
			RETURN;
		END

        IF EXISTS (SELECT 1 FROM tbBook WHERE BookCode = @BookCode AND BookQty > 0 )
			BEGIN
				INSERT INTO tbBorrowDetail (BorrowID, BookCode, BookTitle, BorrowDate, DueDate)
				VALUES (@BorrowID, @BookCode, @BookTitle, @BorrowDate, @DueDate);
				EXEC spRemoveStockQty @BookCode;
				SET  @isSuccess = 1;
			 END
		ELSE
		BEGIN
			RAISERROR('The book does not exist or is out of stock in the tbBook table.', 16, 1);
		END
	END
END;
Go

CREATE PROCEDURE spUpdateBorrowDetail
    @BorrowID int,
    @BookCode int,
    @BookTitle nvarchar(255),
    @DueDate date,
	@isSuccess bit OUTPUT
AS
BEGIN
	UPDATE tbBorrowDetail
    SET 
        BookTitle = @BookTitle,
        DueDate = @DueDate
    WHERE 
        BorrowID = @BorrowID AND 
        BookCode = @BookCode;
	SET @isSuccess = 1;
END
GO

CREATE PROCEDURE spDeleteBorrowDetail
    @BorrowID int,
    @BookCode int
AS
BEGIN
    SET NOCOUNT ON;
    DELETE FROM tbBorrowDetail
    WHERE BorrowID = @BorrowID AND BookCode = @BookCode;
END
GO

CREATE PROCEDURE spUpdateDueDate
    @BorrowID int,
    @BookCode int,
	@NewDueDate DATE
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE tbBorrowDetail SET DueDate = @NewDueDate
    WHERE BorrowID = @BorrowID AND BookCode = @BookCode;
END
GO

-- Renew
CREATE PROCEDURE spInsertRenew
    @RenewDate date,
    @NewDueDate date,
    @MemberID int,
	@BorrowID int,
	@BookCode int,
    @StaffID smallint,
	@RenewID int OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
	DECLARE @MemberName nvarchar(100), @StaffName nvarchar(100), @StaffPosition nvarchar(100)
	SELECT @MemberName = MemberName FROM vGetMemberIDName WHERE MemberID = @MemberID;
    SELECT @StaffName = StaffName, @StaffPosition = StaffPosition FROM vGetStaffIDNamePosition WHERE StaffID = @StaffID;

    IF @RenewDate > GETDATE()
    BEGIN
        RAISERROR('RenewDate cannot be in the future.', 16, 1);
        RETURN;
    END
    
    IF @NewDueDate <= @RenewDate
    BEGIN
        RAISERROR('NewDueDate must be after RenewDate.', 16, 1);
        RETURN;
    END
        INSERT INTO tbRenew (RenewDate, NewDueDate, MemberID, MemberName, BorrowID, BookCode, StaffID, StaffName, StaffPosition)
        VALUES (@RenewDate, @NewDueDate, @MemberID, @MemberName COLLATE SQL_Latin1_General_CP850_Bin, @BorrowID, @BookCode, @StaffID, @StaffName COLLATE SQL_Latin1_General_CP850_Bin, @StaffPosition COLLATE SQL_Latin1_General_CP850_Bin);

		SET @RenewID = (SELECT MAX(RenewID) FROM tbRenew)
END
GO

CREATE PROCEDURE spUpdateRenew
    @RenewID int,
    @RenewDate date,
    @NewDueDate date,
    @MemberID int,
	@BorrowID Int,
    @BookCode int,
    @StaffID smallint
AS
BEGIN
    SET NOCOUNT ON;

    -- Declare variables to hold current MemberName, StaffName, and StaffPosition
    DECLARE @MemberName nvarchar(100), @StaffName nvarchar(100), @StaffPosition nvarchar(100);
	SELECT @MemberName = MemberName FROM vGetMemberIDName WHERE MemberID = @MemberID;
    SELECT @StaffName = StaffName, @StaffPosition = StaffPosition FROM vGetStaffIDNamePosition WHERE StaffID = @StaffID;

    -- Validate RenewDate
    IF @RenewDate > GETDATE()
    BEGIN
        RAISERROR('RenewDate cannot be in the future.', 16, 1);
        RETURN;
    END

    -- Validate NewDueDate
    IF @NewDueDate <= @RenewDate
    BEGIN
        RAISERROR('NewDueDate must be after RenewDate.', 16, 1);
        RETURN;
    END

    -- Update the record
    UPDATE tbRenew
    SET RenewDate = @RenewDate,
        NewDueDate = @NewDueDate,
        MemberID = @MemberID,
        MemberName = @MemberName COLLATE SQL_Latin1_General_CP850_Bin,
		BorrowID = @BorrowID,
        BookCode = @BookCode,
        StaffID = @StaffID,
        StaffName = @StaffName COLLATE SQL_Latin1_General_CP850_Bin,
        StaffPosition = @StaffPosition COLLATE SQL_Latin1_General_CP850_Bin
    WHERE RenewID = @RenewID;
END
GO

-- BorrowExpire
CREATE PROCEDURE spUpdateBorrowExpire
    @BorrowExpireID INT,
    @ExpiredDate DATE,
    @BorrowID INT,
    @MemberID INT,
    @BookTitle NVARCHAR(255)
AS
BEGIN
    UPDATE tbBorrowExpire
    SET
        ExpiredDate = @ExpiredDate,
        BorrowID = @BorrowID,
        MemberID = @MemberID,
        BookTitle = @BookTitle
    WHERE
        BorrowExpireID = @BorrowExpireID;
END
GO

CREATE PROCEDURE spDeleteBorrowExpire
    @BorrowID int,
    @BookCode int
AS
BEGIN
    SET NOCOUNT ON;
    DELETE FROM tbBorrowExpire
    WHERE BorrowID = @BorrowID AND BookCode = @BookCode;
END
GO

-- Return and ReturnDetail
CREATE PROCEDURE spInsertReturnDetail
    @ReturnID int,
    @BorrowID int,
    @BookCode int,
    @BookTitle nvarchar(255),
    @BorrowDate date,
    @DueDate date,
    @Ripped bit,
    @FineAmount money, 
	@isSuccess BIT OUTPUT
AS
BEGIN
	SET NOCOUNT ON;
	SET @isSuccess = 0; 
    BEGIN TRY
        BEGIN TRANSACTION;
        -- Check if a record with the same ReturnID and BookCode already exists
        IF EXISTS (
            SELECT 1 
            FROM tbReturnDetail 
            WHERE ReturnID = @ReturnID AND BookCode = @BookCode
        )
        BEGIN
            -- If the record exists, raise an error
            RAISERROR('A record with the same ReturnID and BookCode already exists.', 16, 1);
            ROLLBACK TRANSACTION;
            RETURN;
        END
        -- If the record does not exist, insert the new record
        INSERT INTO tbReturnDetail (ReturnID, BorrowID, BookCode, BookTitle, BorrowDate, DueDate, Ripped, FineAmount)
        VALUES (@ReturnID, @BorrowID, @BookCode, @BookTitle, @BorrowDate, @DueDate, @Ripped, @FineAmount);

        -- Delete from tbBorrowDetail
		EXEC spDeleteBorrowDetail @BorrowID, @BookCode;
        --DELETE FROM tbBorrowDetail
        --WHERE BorrowID = @BorrowID AND BookCode = @BookCode;

        -- Delete from tbBorrowExpire
		EXEC spDeleteBorrowExpire @BorrowID, @BookCode;
        --DELETE FROM tbBorrowExpire
        --WHERE BorrowID = @BorrowID AND BookCode = @BookCode;
		IF NOT EXISTS (SELECT 1 FROM tbBorrowDetail WHERE BorrowID = @BorrowID)
            AND NOT EXISTS (SELECT 1 FROM tbBorrowExpire WHERE BorrowID = @BorrowID)
        BEGIN
            DELETE FROM tbBorrow WHERE BorrowID = @BorrowID;
        END
		EXEC spAddStockQty @BookCode;
        COMMIT TRANSACTION;
        SET @isSuccess = 1;
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION;
        -- Rethrow the error
        THROW;
    END CATCH
END
GO

CREATE PROCEDURE spUpdateReturn
    @ReturnID int,
    @ReturnDate date,
    @StaffID smallint,
	@isSuccess bit OUTPUT
AS
BEGIN
	SET NOCOUNT ON;
	SET @isSuccess = 0;
	DECLARE @PayDate DATE, @StaffName nvarchar(100), @StaffPosition nvarchar(100)
    SELECT @StaffName = StaffName, @StaffPosition = StaffPosition FROM vGetStaffIDNamePosition WHERE StaffID = @StaffID;
    UPDATE tbReturn
    SET 
        ReturnDate = @ReturnDate,
        StaffID = @StaffID,
        StaffName = @StaffName,
        StaffPosition = @StaffPosition
    WHERE 
        ReturnID = @ReturnID;
		SET @isSuccess = 1;
END
GO

CREATE PROCEDURE spUpdateReturnDetail
    @ReturnID int,
    @BookCode int,
    @BorrowID int,
    @BookTitle nvarchar(255),
    @BorrowDate date,
    @DueDate date,
    @Ripped bit,
    @FineAmount money
AS
BEGIN
    UPDATE tbReturnDetail
    SET 
        BorrowID = @BorrowID,
        BookTitle = @BookTitle,
        BorrowDate = @BorrowDate,
        DueDate = @DueDate,
        Ripped = @Ripped,
        FineAmount = @FineAmount
    WHERE 
        ReturnID = @ReturnID AND 
        BookCode = @BookCode;
END
GO

-- Invoice 
CREATE PROCEDURE spInsertInvoice
    @TotalAmount MONEY,
    @PaidAmount MONEY,
    @ReturnID INT,
    @MemberID INT,
    @StaffID SMALLINT, 
	@InvoiceNO INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
	DECLARE @InvoiceDate DATE, @MemberName nvarchar(100), @StaffName nvarchar(100), @StaffPosition nvarchar(100)
	SELECT @MemberName = MemberName FROM vGetMemberIDName WHERE MemberID = @MemberID;
    SELECT @StaffName = StaffName, @StaffPosition = StaffPosition FROM vGetStaffIDNamePosition WHERE StaffID = @StaffID;
	SET @InvoiceDate = GETDATE();
    -- Insert into tbInvoice
    INSERT INTO tbInvoice (InvoiceDate, TotalAmount, PaidAmount, ReturnID, MemberID, StaffID, StaffName, StaffPosition)
    VALUES (@InvoiceDate, @TotalAmount, @PaidAmount, @ReturnID, @MemberID, @StaffID, @StaffName, @StaffPosition);
	SET @InvoiceNo = (SELECT MAX(InvoiceNo) FROM tbInvoice)
END
GO

CREATE PROCEDURE spUpdateInvoice
    @InvoiceNo INT,
    @PaidAmount MONEY,
    @ReturnID INT,
    @MemberID INT,
    @StaffID SMALLINT
AS
BEGIN
    SET NOCOUNT ON;
	DECLARE @StaffName nvarchar(100), @StaffPosition nvarchar(100)
    SELECT @StaffName = StaffName, @StaffPosition = StaffPosition FROM vGetStaffIDNamePosition WHERE StaffID = @StaffID;
    BEGIN TRY
        BEGIN TRANSACTION;

        UPDATE tbInvoice
        SET 
            PaidAmount = @PaidAmount,
            ReturnID = @ReturnID,
            MemberID = @MemberID,
            StaffID = @StaffID,
            StaffName = @StaffName,
            StaffPosition = @StaffPosition
        WHERE 
            InvoiceNo = @InvoiceNo;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END;
GO

-- Payment
CREATE PROCEDURE spInsertPayment
    @PaidAmount MONEY,
    @ReturnID INT,
    @MemberID INT,
    @StaffID SMALLINT, 
	@PaymentNo INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
	DECLARE @PayDate DATE, @StaffName nvarchar(100), @StaffPosition nvarchar(100)
    SELECT @StaffName = StaffName, @StaffPosition = StaffPosition FROM vGetStaffIDNamePosition WHERE StaffID = @StaffID;
	SET @PayDate = GETDATE();
    -- Insert into tbInvoice
    INSERT INTO tbPayment(PaymentDate, PaidAmount, ReturnID, MemberID, StaffID, StaffName, StaffPosition)
    VALUES (@PayDate,  @PaidAmount, @ReturnID, @MemberID, @StaffID, @StaffName, @StaffPosition);
	SET @PaymentNo = (SELECT MAX(PaymentNo) FROM tbPayment)
END
GO

CREATE PROCEDURE spUpdatePayment
    @PaymentNo INT,
    @PaidAmount MONEY,
    @ReturnID INT,
    @MemberID INT,
    @StaffID SMALLINT
AS
BEGIN
    SET NOCOUNT ON;
	DECLARE @StaffName nvarchar(100), @StaffPosition nvarchar(100)
    SELECT @StaffName = StaffName, @StaffPosition = StaffPosition FROM vGetStaffIDNamePosition WHERE StaffID = @StaffID;
    BEGIN TRY
        BEGIN TRANSACTION;

        UPDATE tbPayment
        SET 
            PaidAmount = @PaidAmount,
            ReturnID = @ReturnID,
            MemberID = @MemberID,
            StaffID = @StaffID,
            StaffName = @StaffName,
            StaffPosition = @StaffPosition
        WHERE 
            PaymentNo = @PaymentNo;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END;
GO

-- Check Condition
CREATE PROCEDURE spCheckMemberExists
    @MemberID INT,
    @Exists BIT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS (SELECT 1 FROM tbMember WHERE MemberID = @MemberID)
    BEGIN
        SET @Exists = 1;
    END
    ELSE
    BEGIN
        SET @Exists = 0;
    END
END;
GO

CREATE PROCEDURE spCheckBorrowExpired
    @MemberID INT,
	@BookCode INT,
    @HasExpired BIT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS ( SELECT 1 FROM tbBorrowExpire  WHERE MemberID = @MemberID AND BookCode = @BookCode )
    BEGIN
        SET @HasExpired = 1;
    END
    ELSE
    BEGIN
        SET @HasExpired = 0;
    END
END;
GO

CREATE PROCEDURE spCheckBorrowLimit
    @MemberID INT,
    @MaxBorrows INT = 5,
    @HasReachedLimit BIT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    -- Check if the member has borrowed more than the allowed number of books
    IF EXISTS (
        SELECT 1
        FROM tbBorrowDetail bd
        JOIN tbBorrow b ON bd.BorrowID = b.BorrowID
        WHERE b.MemberID = @MemberID
        GROUP BY b.MemberID
        HAVING COUNT(bd.BookCode) > @MaxBorrows
    )
    BEGIN
        SET @HasReachedLimit = 1;
    END
    ELSE
    BEGIN
        SET @HasReachedLimit = 0;
    END
END;
GO

-- For Report
CREATE PROCEDURE spImportReport @bd date, @ed date
AS
Begin
	Declare @impID int, @impDate date, @supID int;
	Declare @sn nvarchar(100), @pos nvarchar(50), @ta money

	Delete From tbImportReport;

	Declare csImport Cursor Scroll Dynamic 
	For Select ImportID, ImportDate, SupplierID, StaffName, StaffPosition, TotalAmount From tbImport Where ImportDate Between @bd AND @ed;
	Open csImport
	Fetch First From csImport Into @impID, @impDate, @supID, @sn, @pos, @ta
	While( @@FETCH_STATUS = 0)	
	Begin
		Declare @supName nvarchar(100)
		Select @supName = SupplierName From tbSupplier Where SupplierID = @supID;

		Declare @bt nvarchar(255), @qty tinyint, @un money, @amount money
		Declare csImportDetail Cursor Scroll Dynamic 
		For Select BookTitle, ImportQty, UnitPrice, Amount
		From tbImportDetail Where ImportID = @impID

		Open csImportDetail
		Fetch First From csImportDetail Into @bt, @qty, @un, @amount
		While(@@FETCH_STATUS = 0)
		Begin
			Insert Into tbImportReport Values(@impID, @impDate, @supName, @sn, @pos, @ta, @bt, @qty, @un, @amount)
			Fetch next From csImportDetail Into @bt, @qty, @un, @amount
		End
		Close csImportDetail
		Deallocate csImportDetail
		Fetch next From csImport Into @impID, @impDate, @supID, @sn, @pos, @ta
	End
	Close csImport
	Deallocate csImport
END;
Go

CREATE PROCEDURE spBorrowReport @bd date, @ed date
AS
Begin
	Declare @bID int, @bDate date, @MemID int;
	Declare @sn nvarchar(100), @pos nvarchar(50)

	Delete From tbBorrowReport;

	Declare csBorrow Cursor Scroll Dynamic 
	For Select BorrowID, BorrowDate, MemberID, StaffName, StaffPosition From tbBorrow Where BorrowDate Between @bd AND @ed;
	Open csBorrow
	Fetch First From csBorrow Into @bID, @bDate, @MemID, @sn, @pos
	While( @@FETCH_STATUS = 0)	
	Begin
		Declare @memName nvarchar(100)
		Select @memName = (FirstName + LastName ) From tbMember Where MemberID = @MemID;

		Declare @bt nvarchar(255), @duedate date
		Declare csBorrowDetail Cursor Scroll Dynamic 
		For Select BookTitle, DueDate
		From tbBorrowDetail Where BorrowID = @bID

		Open csBorrowDetail
		Fetch First From csBorrowDetail Into @bt, @duedate
		While(@@FETCH_STATUS = 0)
		Begin
			Insert Into tbBorrowReport Values(@bID, @bDate, @duedate, @bt, @memName, @sn, @pos)
			Fetch next From csBorrowDetail Into @bt, @duedate
		End
		Close csBorrowDetail
		Deallocate csBorrowDetail
		Fetch next From csBorrow Into @bID, @bDate, @MemID, @sn, @pos
	End
	Close csBorrow
	Deallocate csBorrow
END;
Go

CREATE PROCEDURE spReturnReport @bd date, @ed date
AS
Begin
	Declare @rID int, @rDate date, @MemID int;
	Declare @sn nvarchar(100), @pos nvarchar(50)

	Delete From tbReturnReport;

	Declare csReturn Cursor Scroll Dynamic 
	For Select ReturnID, ReturnDate, MemberID, StaffName, StaffPosition From tbReturn Where ReturnDate Between @bd AND @ed;
	Open csReturn
	Fetch First From csReturn Into @rID, @rDate, @MemID, @sn, @pos
	While( @@FETCH_STATUS = 0)	
	Begin
		Declare @memName nvarchar(100)
		Select @memName = (FirstName + LastName ) From tbMember Where MemberID = @MemID;

		Declare @bt nvarchar(255), @duedate date, @status bit, @fineAmount money
		Declare csReturnDetail Cursor Scroll Dynamic 
		For Select BookTitle, DueDate, Ripped, FineAmount
		From tbReturnDetail Where ReturnID = @rID

		Open csReturnDetail
		Fetch First From csReturnDetail Into @bt, @duedate, @status, @fineAmount
		While(@@FETCH_STATUS = 0)
		Begin
			Insert Into tbReturnReport Values(@rID, @rDate, @duedate, @bt, @status, @fineAmount, @memName, @sn, @pos)
			Fetch next From csReturnDetail Into @bt, @duedate, @status, @fineAmount
		End
		Close csReturnDetail
		Deallocate csReturnDetail
		Fetch next From csReturn Into @rID, @rDate, @MemID, @sn, @pos
	End
	Close csReturn
	Deallocate csReturn
END;
Go

exec spReturnReport '2024-06-06', '2024-06-24';
select * from tbReturnReport;
declare @a bit;
exec spCheckBorrowExpired 1007, 2010, @HasExpired=@a output;
SELECT @a AS HasExpired;

select * from tbBorrowDetail  Where borrowID = 3012;
select * from tbBorrowExpire  Where borrowID = 3012;
select * from tbImport;


