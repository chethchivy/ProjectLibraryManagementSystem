-- Book
CREATE PROCEDURE spInsertBooks
    @Books BookType READONLY,
    @rowsAffected int output
AS
BEGIN
    SET NOCOUNT ON;

    -- Check for duplicate records in tbBook
    IF EXISTS (
        SELECT 1
        FROM tbBook AS b
        INNER JOIN @Books AS nb ON b.BookTitle Collate SQL_Latin1_General_CP850_Bin = nb.BookTitle Collate SQL_Latin1_General_CP850_Bin
		AND b.Author Collate SQL_Latin1_General_CP850_Bin = nb.Author Collate SQL_Latin1_General_CP850_Bin
    )
    BEGIN
        -- Handle duplicate records
        RAISERROR('Some of the books being inserted already exist in the database.', 16, 1);
        RETURN;
    END;

    -- Insert non-duplicate records into tbBook
    INSERT INTO tbBook (BookTitle, Genres, Author, PublishYear, BookQty, LateFee, Price)
    SELECT BookTitle, Genres, Author, PublishYear, BookQty, LateFee, Price
    FROM @Books;

    SET @rowsAffected = @@ROWCOUNT;
END;
Go

CREATE PROCEDURE spUpdateBooks
    @Books BookType READONLY,
    @rowsAffected int output
AS
BEGIN
    SET NOCOUNT ON;

    -- Check for duplicate records in tbBook
    IF EXISTS (
        SELECT 1
        FROM tbBook AS b
        INNER JOIN @Books AS nb ON b.BookTitle Collate SQL_Latin1_General_CP850_Bin = nb.BookTitle Collate SQL_Latin1_General_CP850_Bin
		AND b.Author Collate SQL_Latin1_General_CP850_Bin = nb.Author Collate SQL_Latin1_General_CP850_Bin AND b.BookCode <> nb.BookCode
    )
    BEGIN
        -- Handle duplicate records
        RAISERROR('Some of the books have already existed in the database.', 16, 1);
        RETURN;
    END;

    -- Insert non-duplicate records into tbBook
		UPDATE b
		SET 
			b.BookTitle = u.BookTitle,
			b.Genres = u.Genres,
			b.Author = u.Author,
			b.PublishYear = u.PublishYear,
			b.BookQty = u.BookQty,
			b.LateFee = u.LateFee,
			b.Price = u.Price
		FROM tbBook b
		INNER JOIN @Books u ON b.BookCode = u.BookCode;

		SET @rowsAffected = @@ROWCOUNT;
END;
Go

-- Staff
CREATE PROCEDURE spInsertStaffs
    @Staffs StaffType READONLY,
    @rowsAffected int OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    -- Check for duplicate records in tbStaff
    IF EXISTS (
        SELECT 1
        FROM tbStaff AS s
        INNER JOIN @Staffs AS ns ON s.FirstName = ns.FirstName COLLATE SQL_Latin1_General_CP850_Bin
                               AND s.LastName = ns.LastName COLLATE SQL_Latin1_General_CP850_Bin
                               AND s.PersonalNumber = ns.PersonalNumber COLLATE SQL_Latin1_General_CP850_Bin
							   AND s.BirthDate = ns.BirthDate
    )
    BEGIN
        -- Handle duplicate records
        RAISERROR('Some of the staff being inserted already exist in the database.', 16, 1);
        RETURN;
    END;

    -- Insert non-duplicate records into tbStaff
    INSERT INTO tbStaff (
        FirstName, LastName, Sex, BirthDate, StaffPosition, HouseNo, StreetNo, Sangkat, Khann, Province,
        ContactNumber, PersonalNumber, Salary, HireDate, Photo, StopWork
    )
    SELECT 
        FirstName, LastName, Sex, BirthDate, StaffPosition, HouseNo, StreetNo, Sangkat, Khann, Province,
        ContactNumber, PersonalNumber, Salary, HireDate, Photo, StopWork
    FROM @Staffs;

    SET @rowsAffected = @@ROWCOUNT;
END;
Go

-- Borrow and BorrowDetail
CREATE PROCEDURE spInsertBorrowWithDetails
    @BorrowDate date,
    @MemberID int,
    @StaffID smallint,
    @BookDetails dbo.BookDetailsType READONLY,
	@rowAffected int output
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @BorrowID int;
	DECLARE @MemberName NVARCHAR(100), @StaffName NVARCHAR(100), @StaffPosition NVARCHAR(100);

    -- Retrieve member and staff details
    SELECT @MemberName = CONCAT(FirstName, ' ', LastName) FROM tbMember WHERE MemberID = @MemberID;
    SELECT @StaffName = CONCAT(FirstName, ' ', LastName), @StaffPosition = StaffPosition FROM tbStaff WHERE StaffID = @StaffID;

    -- Insert into tbBorrow
    INSERT INTO tbBorrow (BorrowDate, MemberID, MemberName, StaffID, StaffName, StaffPosition)
    VALUES (@BorrowDate, @MemberID, @MemberName, @StaffID, @StaffName, @StaffPosition);

    -- Get the BorrowID of the newly inserted record
    SET @BorrowID = SCOPE_IDENTITY();

    -- Insert into tbBorrowDetail using the provided BookDetails
    INSERT INTO tbBorrowDetail (BorrowID, BookCode, BookTitle, BorrowDate, DueDate)
    SELECT @BorrowID, bd.BookCode, bd.BookTitle, bd.BorrowDate, bd.DueDate
    FROM @BookDetails bd;
    
    -- Get the number of rows affected by the insert into tbBorrowDetail
    SET @rowAffected = @@ROWCOUNT;

    -- Update the BookQty in tbBook
    UPDATE tbBook
    SET BookQty = BookQty - 1
    FROM @BookDetails bd
    WHERE tbBook.BookCode = bd.BookCode;

    SELECT @BorrowID AS BorrowID;
END;
GO

CREATE PROCEDURE spUpdateBorrowWithDetails
    @BorrowID int,
    @MemberID int,
    @StaffID smallint,
    @BookDetails dbo.BookDetailsType READONLY,
    @rowAffected int output
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @OldBookDetails TABLE (
        BookCode int
    );
    DECLARE @MemberName NVARCHAR(100), @StaffName NVARCHAR(100), @StaffPosition NVARCHAR(100);

    -- Retrieve member and staff details
    SELECT @MemberName = CONCAT(FirstName, ' ', LastName) FROM tbMember WHERE MemberID = @MemberID;
    SELECT @StaffName = CONCAT(FirstName, ' ', LastName), @StaffPosition = StaffPosition FROM tbStaff WHERE StaffID = @StaffID;

    -- Update the borrow record in tbBorrow
    UPDATE tbBorrow
    SET MemberID = @MemberID, MemberName = @MemberName, StaffID = @StaffID, StaffName = @StaffName, StaffPosition = @StaffPosition
    WHERE BorrowID = @BorrowID;

    -- Store the old borrow details
    INSERT INTO @OldBookDetails (BookCode)
    SELECT BookCode FROM tbBorrowDetail WHERE BorrowID = @BorrowID;

    -- Delete old borrow details
    DELETE FROM tbBorrowDetail WHERE BorrowID = @BorrowID;

    -- Insert new borrow details using the provided BookDetails
    INSERT INTO tbBorrowDetail (BorrowID, BookCode, BookTitle, BorrowDate, DueDate)
    SELECT @BorrowID, bd.BookCode, bd.BookTitle, bd.BorrowDate, bd.DueDate
    FROM @BookDetails bd;

    -- Get the number of rows affected by the insert into tbBorrowDetail
    SET @rowAffected = @@ROWCOUNT;

    -- Adjust the BookQty in tbBook
    -- First, restore the BookQty for the old details
    UPDATE tbBook
    SET BookQty = BookQty + 1
    FROM @OldBookDetails ob
    WHERE tbBook.BookCode = ob.BookCode;

    -- Then, decrease the BookQty for the new details
    UPDATE tbBook
    SET BookQty = BookQty - 1
    FROM @BookDetails bd
    WHERE tbBook.BookCode = bd.BookCode;
    SELECT @BorrowID AS BorrowID;
END;
GO

-- Return and ReturnDetail
CREATE PROCEDURE spInsertReturnWithDetails
    @ReturnDate date,
    @MemberID int,
    @StaffID smallint,
    @ReturnDetails dbo.ReturnDetailType READONLY,
	@rowAffected int output,
	@ReturnID int output
AS
BEGIN
    SET NOCOUNT ON;
	DECLARE @MemberName NVARCHAR(100), @StaffName NVARCHAR(100), @StaffPosition NVARCHAR(100);

    -- Retrieve member and staff details
    SELECT @MemberName = MemberName FROM vGetMemberIDName WHERE MemberID = @MemberID;
    SELECT @StaffName = StaffName, @StaffPosition = StaffPosition FROM vGetStaffIDNamePosition WHERE StaffID = @StaffID;
	BEGIN TRY
        BEGIN TRANSACTION;
		-- Insert into tbBorrow
		INSERT INTO tbReturn(ReturnDate, MemberID, MemberName, StaffID, StaffName, StaffPosition)
		VALUES (@ReturnDate, @MemberID, @MemberName, @StaffID, @StaffName, @StaffPosition);

		-- Get the BorrowID of the newly inserted record
		SET @ReturnID = (SELECT MAX(ReturnID) FROM tbReturn)

		-- Insert into tbBorrowDetail using the provided BookDetails
		INSERT INTO tbReturnDetail (ReturnID, BorrowID, BookCode, BookTitle, BorrowDate, DueDate, Ripped, FineAmount)
		SELECT @ReturnID, rd.BorrowID, rd.BookCode, rd.BookTitle, rd.BorrowDate, rd.DueDate, rd.Ripped, rd.FineAmount
		FROM @ReturnDetails rd;
		
		--DELETE FROM tbBorrowDetail
  --      WHERE BorrowID IN (SELECT DISTINCT BorrowID FROM @ReturnDetails)
  --        AND BookCode IN (SELECT BookCode FROM @ReturnDetails);
		-- Get the number of rows affected by the insert into tbBorrowDetail
		SET @rowAffected = @@ROWCOUNT;
		-- Delete expired books from tbBorrowExpire
        DELETE FROM tbBorrowExpire
        WHERE BorrowID IN (SELECT DISTINCT BorrowID FROM @ReturnDetails)
          AND BookCode IN (SELECT BookCode FROM @ReturnDetails);

        -- Delete from tbBorrowDetail if the book is not expired
        DELETE FROM tbBorrowDetail
        WHERE BorrowID IN (SELECT DISTINCT BorrowID FROM @ReturnDetails)
          AND BookCode IN (SELECT BookCode FROM @ReturnDetails);
          --AND NOT EXISTS (
          --    SELECT 1 FROM tbBorrowExpire
          --    WHERE tbBorrowExpire.BorrowID = tbBorrowDetail.BorrowID
          --    AND tbBorrowExpire.BookCode = tbBorrowDetail.BookCode
          --);

        -- Optional: Clean up tbBorrow if no more books are associated with that BorrowID
        DELETE FROM tbBorrow
        WHERE BorrowID IN (SELECT DISTINCT BorrowID FROM @ReturnDetails)
          AND NOT EXISTS (SELECT 1 FROM tbBorrowDetail WHERE tbBorrowDetail.BorrowID = tbBorrow.BorrowID)
          AND NOT EXISTS (SELECT 1 FROM tbBorrowExpire WHERE tbBorrowExpire.BorrowID = tbBorrow.BorrowID);

		  Update tbBook SET BookQty = BookQty + 1 WHERE BookCode IN (SELECT BookCode FROM @ReturnDetails);
		COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END;
GO

-- Import and ImportDetail
CREATE PROCEDURE spInsertImportWithDetails
    @ImportDate date,
	@TotalAmount money,
    @SupplierID tinyint,
    @StaffID smallint,
    @ImportDetails dbo.tbImportDetailType READONLY,
	@rowAffected int output,
	@ImportID int output
AS
BEGIN
    SET NOCOUNT ON;
	DECLARE @SupplierName NVARCHAR(100), @StaffName NVARCHAR(100), @StaffPosition NVARCHAR(100);

    -- Retrieve member and staff details
    SELECT @SupplierName = SupplierName FROM vGetSuppliersName WHERE SupplierID = @SupplierID;
    SELECT @StaffName = StaffName, @StaffPosition = StaffPosition FROM vGetStaffIDNamePosition WHERE StaffID = @StaffID;
	BEGIN TRY
        BEGIN TRANSACTION;
		-- Insert into tbBorrow
		INSERT INTO tbImport(ImportDate, TotalAmount, SupplierID, SupplierName, StaffID, StaffName, StaffPosition)
		VALUES (@ImportDate, @TotalAmount, @SupplierID, @SupplierName, @StaffID, @StaffName, @StaffPosition);

		-- Get the BorrowID of the newly inserted record
		SET @ImportID = (SELECT MAX(ImportID) FROM tbImport)

		-- Insert into tbBorrowDetail using the provided BookDetails
		INSERT INTO tbImportDetail(ImportID, BookCode, BookTitle, ImportQty, UnitPrice, Amount)
		SELECT @ImportID, id.BookCode, id.BookTitle, id.ImportQty, id.UnitPrice, id.Amount
		FROM @ImportDetails id;
		
		UPDATE b
        SET b.BookQty = b.BookQty + id.ImportQty
        FROM tbBook b
        INNER JOIN @ImportDetails id ON b.BookCode = id.BookCode;
        SET @rowAffected = @@ROWCOUNT;
		COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END;
GO

SELECT COUNT(*) FROM tbBorrowDetail bd JOIN tbBorrow b ON bd.BorrowID = b.BorrowID WHERE b.MemberID = 1009;
select * from tbBorrowDetail
select * from tbBook where BookCode = 2008

select * from tbImportDetail
select be.BookTitle from tbBorrowDetail b inner join  tbBorrowExpire be on b.BorrowID = be.BorrowID where be.MemberID = 2;
delete from tbBorrow where BorrowID = 3010;
select * from tbBorrowExpire
select * from tbBorrowDetail;
select * from tbReturnDetail
Go