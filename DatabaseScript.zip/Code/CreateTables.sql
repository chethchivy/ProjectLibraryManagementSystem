﻿CREATE TABLE tbBook(
	BookCode int Primary Key IDENTITY(1,1) Not Null,
	BookTitle nvarchar(255) Collate SQL_Latin1_General_CP850_Bin Not Null,
	Genres nvarchar(50) Collate SQL_Latin1_General_CP850_Bin Not Null,
	Author nvarchar(50) Collate SQL_Latin1_General_CP850_Bin Not Null,
	PublishYear smallint Not Null,
	BookQty tinyint Null CHECK (BookQty >= 0),
	LateFee money Not Null CHECK (LateFee >= 0),
	Price money Null CHECK (Price >= 0)
)
Go

CREATE TABLE tbSupplier(
	SupplierID tinyint Primary Key IDENTITY(1,1) Not Null,
	SupplierName nvarchar(100) Collate SQL_Latin1_General_CP850_Bin Not Null,
	SupplierAddress nvarchar(255) Collate SQL_Latin1_General_CP850_Bin Not Null,
	PhoneNumber1 nvarchar(20) Collate SQL_Latin1_General_CP850_Bin Not Null,
	PhoneNumber2 nvarchar(20) Collate SQL_Latin1_General_CP850_Bin Not Null,
	CONSTRAINT CHK_PhoneNumber1_Length CHECK (LEN(PhoneNumber1) >= 7),
    CONSTRAINT CHK_PhoneNumber2_Length CHECK (PhoneNumber2 IS NULL OR LEN(PhoneNumber2) >= 7),
    CONSTRAINT UQ_PhoneNumber1 UNIQUE (PhoneNumber1),
    CONSTRAINT UQ_PhoneNumber2 UNIQUE (PhoneNumber2)
)
Go

CREATE TABLE tbStaff(
	StaffID smallint Primary Key IDENTITY(1,1) Not Null,
	FirstName nvarchar(50) Collate SQL_Latin1_General_CP850_Bin Not Null,
	LastName nvarchar(50) Collate SQL_Latin1_General_CP850_Bin Not Null,
	Sex nchar(6) Collate SQL_Latin1_General_CP850_Bin  Not Null CHECK (Sex IN ('ប្រុស', 'ស្រី')),
	BirthDate date Not Null CHECK (BirthDate <= GETDATE()),
	StaffPosition nvarchar(100) Collate SQL_Latin1_General_CP850_Bin Not Null,
	HouseNo nvarchar(15) Collate SQL_Latin1_General_CP850_Bin Null,
	StreetNo nvarchar(25) Collate SQL_Latin1_General_CP850_Bin Null,
	Sangkat nvarchar(50) Collate SQL_Latin1_General_CP850_Bin Not Null,
	Khann nvarchar(50) Collate SQL_Latin1_General_CP850_Bin Not Null,
	Province nvarchar(50) Collate SQL_Latin1_General_CP850_Bin Not Null,
	ContactNumber nvarchar(20) Collate SQL_Latin1_General_CP850_Bin Null,
	PersonalNumber nvarchar(20) Collate SQL_Latin1_General_CP850_Bin Not Null,
	Salary money Not Null CHECK (Salary >= 0),
	HireDate date Not Null CHECK (HireDate <= GETDATE()),
	Photo varbinary(max) Null,
	StopWork bit Null
)
GO

CREATE TABLE tbMember(
	MemberID int Primary Key IDENTITY(1,1) Not Null,
	FirstName nvarchar(50) Collate SQL_Latin1_General_CP850_Bin Not Null,
	LastName nvarchar(50) Collate SQL_Latin1_General_CP850_Bin Not Null,
	Sex nchar(6) Collate SQL_Latin1_General_CP850_Bin  Not Null CHECK (Sex IN ('ប្រុស', 'ស្រី')),
	BirthDate date Not Null CHECK (BirthDate <= GETDATE()),
	Sangkat nvarchar(50) Collate SQL_Latin1_General_CP850_Bin Not Null,
	Khann nvarchar(50) Collate SQL_Latin1_General_CP850_Bin Not Null,
	Province nvarchar(50) Collate SQL_Latin1_General_CP850_Bin Not Null,
	PhoneNumber nvarchar(50) Collate SQL_Latin1_General_CP850_Bin Not Null UNIQUE CHECK (LEN(PhoneNumber) >= 7),
	Photo VARBINARY(max) Null
)
Go

CREATE TABLE tbUser(
	UserID int Primary Key IDENTITY(1,1) Not Null,
	UserName varchar(20) Not Null UNIQUE,
	UserPassword varchar(20) Not Null CHECK (LEN(UserPassword) >= 8),
	StaffID smallint Not Null,
	StaffName nvarchar(100) Collate SQL_Latin1_General_CP850_Bin Not Null,
	StaffPosition nvarchar(100) Collate SQL_Latin1_General_CP850_Bin Not Null,
	Constraint FKStaffID1 Foreign Key(StaffID) References tbStaff(StaffID) On Delete Cascade On Update Cascade
)
Go

CREATE TABLE tbCard(
	CardID int Primary Key IDENTITY(1,1) Not Null,
	CreateDate date Not Null CHECK (CreateDate <= GETDATE()),
    Expire date Not Null CHECK (Expire > CreateDate),
	MemberID int Not Null,
	MemberName nvarchar(100) Collate SQL_Latin1_General_CP850_Bin Not Null,
	StaffID smallint Not Null,
	StaffName nvarchar(100) Collate SQL_Latin1_General_CP850_Bin Not Null,
	StaffPosition nvarchar(100) Collate SQL_Latin1_General_CP850_Bin Not Null,
	Constraint FKMemberID1 Foreign Key(MemberID) References tbMember(MemberID) On Delete Cascade On Update Cascade,
	Constraint FKStaffID2 Foreign Key(StaffID) References tbStaff(StaffID) On Delete Cascade On Update Cascade
)
Go

CREATE TABLE tbImport(
	ImportID int Primary Key IDENTITY(1,1) Not Null,
	ImportDate date Not Null CHECK (ImportDate <= GETDATE()),
    TotalAmount Money Null CHECK (TotalAmount >= 0),
	SupplierID tinyint Not Null,
	SupplierName nvarchar(100) Collate SQL_Latin1_General_CP850_Bin Not Null,
	StaffID smallint Not Null,
	StaffName nvarchar(100) Collate SQL_Latin1_General_CP850_Bin Not Null,
	StaffPosition nvarchar(100) Collate SQL_Latin1_General_CP850_Bin Not Null,
	Constraint FKSupplierID Foreign Key(SupplierID) References tbSupplier(SupplierID) On Delete Cascade On Update Cascade,
	Constraint FKStaffID3 Foreign Key(StaffID) References tbStaff(StaffID) On Delete Cascade On Update Cascade
)
Go

CREATE TABLE tbBorrow(
	BorrowID int Primary Key IDENTITY(1,1) Not Null,
	BorrowDate date Not Null CHECK (BorrowDate <= GETDATE()),
	MemberID int Not Null,
	MemberName nvarchar(100) Collate SQL_Latin1_General_CP850_Bin Not Null,
	StaffID smallint Not Null,
	StaffName nvarchar(100) Collate SQL_Latin1_General_CP850_Bin Not Null,
	StaffPosition nvarchar(100) Collate SQL_Latin1_General_CP850_Bin Not Null,
	Constraint FKMemberID2 Foreign Key(MemberID) References tbMember(MemberID) On Delete Cascade On Update Cascade,
	Constraint FKStaffID4 Foreign Key(StaffID) References tbStaff(StaffID) On Delete Cascade On Update Cascade
)
Go

CREATE TABLE tbReturn(
	ReturnID int Primary Key IDENTITY(1,1) Not Null,
	ReturnDate date Not Null CHECK (ReturnDate <= GETDATE()),
	MemberID int Not Null,
	MemberName nvarchar(100) Collate SQL_Latin1_General_CP850_Bin Not Null,
	StaffID smallint Not Null,
	StaffName nvarchar(100) Collate SQL_Latin1_General_CP850_Bin Not Null,
	StaffPosition nvarchar(100) Collate SQL_Latin1_General_CP850_Bin Not Null,
	Constraint FKMemberID3 Foreign Key(MemberID) References tbMember(MemberID) On Delete Cascade On Update Cascade,
	Constraint FKStaffID5 Foreign Key(StaffID) References tbStaff(StaffID) On Delete Cascade On Update Cascade,
)
Go

CREATE TABLE tbRenew(
	RenewID int Primary Key IDENTITY(1,1) Not Null,
	RenewDate date Not Null CHECK (RenewDate <= GETDATE()),
    NewDueDate date Not Null CHECK (NewDueDate > RenewDate),
	MemberID int Not Null,
	MemberName nvarchar(100) Collate SQL_Latin1_General_CP850_Bin Not Null,
	BorrowID int Not Null,
	BookCode int Not Null,
	StaffID smallint Not Null,
	StaffName nvarchar(100) Collate SQL_Latin1_General_CP850_Bin Not Null,
	StaffPosition nvarchar(100) Collate SQL_Latin1_General_CP850_Bin Not Null,
	Constraint FKMemberID4 Foreign Key(MemberID) References tbMember(MemberID) On Delete Cascade On Update Cascade,
	Constraint FKStaffID6 Foreign Key(StaffID) References tbStaff(StaffID) On Delete Cascade On Update Cascade,
	Constraint FKBorrowID4 Foreign Key(BorrowID) References tbBorrow(BorrowID) On Delete Cascade On Update Cascade
)
Go

CREATE TABLE tbPayment(
	PaymentNo int Primary Key IDENTITY(1,1) Not Null,
	PaymentDate date Not Null CHECK (PaymentDate <= GETDATE()),
    PaidAmount money Not Null CHECK (PaidAmount >= 0),
	ReturnID int Not Null,
	MemberID int Not Null,
	StaffID smallint Not Null,
	StaffName nvarchar(100) Collate SQL_Latin1_General_CP850_Bin Not Null,
	StaffPosition nvarchar(100) Collate SQL_Latin1_General_CP850_Bin Not Null,
	Constraint FKReturnID1 Foreign Key(ReturnID) References tbReturn(ReturnID) On Delete Cascade On Update Cascade,
	Constraint FKMemberID5 Foreign Key(MemberID) References tbMember(MemberID),
	Constraint FKStaffID7 Foreign Key(StaffID) References tbStaff(StaffID)
)
Go 

CREATE TABLE tbInvoice(
	InvoiceNo int Primary Key IDENTITY(1,1) Not Null,
	InvoiceDate date Not Null CHECK (InvoiceDate <= GETDATE()),
    TotalAmount money Not Null CHECK (TotalAmount >= 0),
    PaidAmount money Not Null CHECK (PaidAmount >= 0 AND PaidAmount <= TotalAmount),
	ReturnID int Not Null,
	MemberID int Not Null,
	StaffID smallint Not Null,
	StaffName nvarchar(100) Collate SQL_Latin1_General_CP850_Bin Not Null,
	StaffPosition nvarchar(100) Collate SQL_Latin1_General_CP850_Bin Not Null,
	Constraint FKReturnID2 Foreign Key(ReturnID) References tbReturn(ReturnID) On Delete Cascade On Update Cascade,
	Constraint FKMemberID6 Foreign Key(MemberID) References tbMember(MemberID),
	Constraint FKStaffID8 Foreign Key(StaffID) References tbStaff(StaffID)
)
Go

CREATE TABLE tbBorrowExpire(
	BorrowExpireID int Primary Key IDENTITY(1,1) Not Null,
	ExpiredDate date Not Null CHECK (ExpiredDate <= GETDATE()),
	BorrowID int Not Null,
	MemberID int Not Null,
	BookCode int Not Null,
	BookTitle nvarchar(255) Collate SQL_Latin1_General_CP850_Bin Not Null,
	Constraint FKBorrowID1 Foreign Key(BorrowID) References tbBorrow(BorrowID) On Delete Cascade On Update Cascade,
	Constraint FKMemberID7 Foreign Key(MemberID) References tbMember(MemberID),
)
Go

CREATE TABLE tbImportDetail(
	ImportID int Not Null,
	BookCode int Not Null,
	BookTitle nvarchar(255) Collate SQL_Latin1_General_CP850_Bin Not Null,
	ImportQty tinyint Not Null CHECK (ImportQty >= 0),
    UnitPrice money Not Null CHECK (UnitPrice >= 0),
	Amount money Not Null,
	Constraint FKImportID Foreign Key(ImportID) References tbImport(ImportID) On Delete Cascade On Update Cascade,
	Constraint FKBookCode1 Foreign Key(BookCode) References tbBook(BookCode) On Delete Cascade On Update Cascade,
	Constraint PKImportIDBookCode Primary Key(ImportID, BookCode)
)
Go

CREATE TABLE tbBorrowDetail(
	BorrowID int Not Null,
	BookCode int Not Null,
	BookTitle nvarchar(255) Not Null,
	BorrowDate date Not Null CHECK (BorrowDate <= GETDATE()),
    DueDate date Not Null CHECK (DueDate > BorrowDate),
	Constraint FKBorrowID2 Foreign Key(BorrowID) References tbBorrow(BorrowID) On Delete Cascade On Update Cascade,
	Constraint FKBookCode2 Foreign Key(BookCode) References tbBook(BookCode) On Delete Cascade On Update Cascade,
	Constraint PKBorrowIDBookCode Primary Key(BorrowID, BookCode)
)
Go

CREATE TABLE tbReturnDetail(
	ReturnID int Not Null,
	BorrowID int Not Null,
	BookCode int Not Null,
	BookTitle nvarchar(255) Collate SQL_Latin1_General_CP850_Bin,
	BorrowDate date Not Null,
	DueDate date Not Null,
	Ripped bit Null,
	FineAmount money Null,
	Constraint FKReturnID3 Foreign Key(ReturnID) References tbReturn(ReturnID) On Delete Cascade On Update Cascade,
	Constraint FKBookCode3 Foreign Key(BookCode) References tbBook(BookCode) On Delete Cascade On Update Cascade,
	Constraint FKBorrowID3 Foreign Key(BorrowID) References tbBorrow(BorrowID) On Delete Cascade On Update Cascade,
	Constraint PKReturnIDBookCode Primary Key(ReturnID, BookCode),
    CONSTRAINT CK_FineAmount CHECK (FineAmount >= 0 OR FineAmount IS NULL),
    CONSTRAINT CK_Ripped CHECK (Ripped IN (0, 1) OR Ripped IS NULL)
)
Go

CREATE TABLE tbProvince (
    ProvinceCode INT PRIMARY KEY IDENTITY(1,1) NOT NULL,
    ProvinceName NVARCHAR(255) Collate SQL_Latin1_General_CP850_Bin NOT NULL
);
Go

CREATE TABLE tbDistrict (
    DistrictCode INT PRIMARY KEY IDENTITY(1,1) NOT NULL,
    DistrictName NVARCHAR(255) Collate SQL_Latin1_General_CP850_Bin NOT NULL,
    ProvinceCode INT,
    FOREIGN KEY (ProvinceCode) REFERENCES tbProvince(ProvinceCode) On Delete Cascade On Update Cascade,
);
Go

CREATE TABLE tbCommune (
    CommuneCode INT PRIMARY KEY IDENTITY(1,1) NOT NULL,
    CommuneName NVARCHAR(255) Collate SQL_Latin1_General_CP850_Bin NOT NULL,
    DistrictCode INT,
    FOREIGN KEY (DistrictCode) REFERENCES tbDistrict(DistrictCode) On Delete Cascade On Update Cascade,
);
Go

-- Table for Report
CREATE TABLE tbImportReport(
	ImportID INT,
	ImportDate DATE,
	SupplierName NVARCHAR(100),
	StaffName NVARCHAR(100),
	StaffPosition NVARCHAR(50),
	TotalAmount MONEY,
	BookTitle NVARCHAR(255),
	ImportQty TINYINT,
	UnitPrice MONEY,
	Amount MONEY
);
Go

CREATE TABLE tbBorrowReport(
	BorrowID INT,
	BorrowDate DATE,
	DueDate DATE,
	BookTitle NVARCHAR(255),
	MemberName NVARCHAR(100),
	StaffName NVARCHAR(100),
	StaffPosition NVARCHAR(50),
);
Go

CREATE TABLE tbReturnReport(
	ReturnID INT,
	ReturnDate DATE,
	DueDate DATE,
	BookTitle NVARCHAR(255),
	Ripped BIT,
	FineAmount MONEY,
	MemberName NVARCHAR(100),
	StaffName NVARCHAR(100),
	StaffPosition NVARCHAR(50),
);
Go

select * from tbRenew;
select * from tbBorrowDetail;
select * from tbBorrowExpire;