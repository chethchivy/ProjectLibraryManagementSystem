CREATE TRIGGER UpdateStaffPositionInUser
ON tbStaff
AFTER UPDATE
AS
BEGIN
    -- Update the StaffPosition in tbUser if it has changed in tbStaff
    UPDATE u
    SET u.StaffPosition = i.StaffPosition
    FROM tbUser u
    INNER JOIN inserted i ON u.StaffID = i.StaffID
    INNER JOIN deleted d ON u.StaffID = d.StaffID
    WHERE i.StaffPosition <> d.StaffPosition;
END;
Go

CREATE TRIGGER trgAfterInsertImportDetail
ON tbImportDetail
AFTER INSERT
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE tbImport
    SET TotalAmount = (
        SELECT SUM(Amount)
        FROM tbImportDetail
        WHERE tbImportDetail.ImportID = inserted.ImportID
    )
    FROM tbImport
    JOIN inserted ON tbImport.ImportID = inserted.ImportID;
END;
Go 

CREATE TRIGGER trgAfterUpdateImportDetail
ON tbImportDetail
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE tbImport
    SET TotalAmount = (
        SELECT SUM(Amount)
        FROM tbImportDetail
        WHERE tbImportDetail.ImportID = inserted.ImportID
    )
    FROM tbImport
    JOIN inserted ON tbImport.ImportID = inserted.ImportID;
END;
Go 

CREATE TRIGGER trgAddAndRemoveExpiredBorrow
ON tbBorrowDetail
AFTER INSERT, UPDATE
AS
BEGIN
    -- Insert expired borrow details into tbBorrowExpire
    INSERT INTO tbBorrowExpire (ExpiredDate, BorrowID, MemberID, BookCode, BookTitle)
    SELECT 
        GETDATE() AS ExpiredDate,
        i.BorrowID,
        m.MemberID,
        i.BookCode,
        i.BookTitle
    FROM 
        inserted i
    INNER JOIN tbBorrow b ON i.BorrowID = b.BorrowID
    INNER JOIN tbMember m ON b.MemberID = m.MemberID
    WHERE 
        i.DueDate <= GETDATE();

    -- Delete expired borrow details from tbBorrowDetail
    DELETE FROM tbBorrowDetail
    WHERE 
        BorrowID IN (SELECT BorrowID FROM inserted WHERE DueDate <= GETDATE())
        AND BookCode IN (SELECT BookCode FROM inserted WHERE DueDate <= GETDATE());
END;
GO


CREATE TRIGGER trgAddExpiredBorrow
ON tbBorrowDetail
AFTER INSERT, UPDATE
AS
BEGIN
    INSERT INTO tbBorrowExpire (ExpiredDate, BorrowID, MemberID, BookCode, BookTitle)
    SELECT 
        GETDATE() AS ExpiredDate,
        i.BorrowID,
        m.MemberID,
		i.BookCode,
        i.BookTitle
    FROM 
        inserted i
    INNER JOIN tbBorrow b ON i.BorrowID = b.BorrowID
    INNER JOIN tbMember m ON b.MemberID = m.MemberID
    WHERE 
        i.DueDate <= GETDATE();
END;
GO

CREATE TRIGGER trgAfterUpdateBorrowDetail
ON tbBorrowDetail
AFTER UPDATE
AS
BEGIN
    DECLARE @BorrowID int, @BookCode int, @ExpiredDate date;
    
    SELECT @BorrowID = INSERTED.BorrowID, @BookCode = INSERTED.BookCode, @ExpiredDate = GETDATE()
    FROM INSERTED
    WHERE INSERTED.DueDate <= GETDATE();
    
    IF @BorrowID IS NOT NULL AND @BookCode IS NOT NULL
    BEGIN
        EXEC spHandleBookExpiration @BorrowID, @BookCode, @ExpiredDate;
    END
END
GO

CREATE TRIGGER trgStopWorkSalary
ON tbStaff
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE tbStaff
    SET Salary = 0
    FROM tbStaff
    JOIN inserted i ON tbStaff.StaffID = i.StaffID
    WHERE i.StopWork = 1;
END;
GO

select * from tbBorrowExpire
select * from tbBorrowDetail
select * from tbImportDetail
select * from tbStaff;
declare @is bit
exec spUpdateImportDetail 1, 2, 6, 12, @isSuccess = @is
