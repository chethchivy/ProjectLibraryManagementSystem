CREATE TYPE BookType AS TABLE
(
    BookCode INT,
    BookTitle NVARCHAR(255),
    Genres NVARCHAR(50),
    Author NVARCHAR(50),
    PublishYear SMALLINT,
    BookQty TINYINT,
    LateFee MONEY,
    Price MONEY
);
GO

CREATE TYPE StaffType AS TABLE (
	StaffID smallint,
    FirstName nvarchar(50) COLLATE SQL_Latin1_General_CP850_Bin,
    LastName nvarchar(50) COLLATE SQL_Latin1_General_CP850_Bin,
    Sex nchar(6) COLLATE SQL_Latin1_General_CP850_Bin,
    BirthDate date,
    StaffPosition nvarchar(100) COLLATE SQL_Latin1_General_CP850_Bin,
    HouseNo nvarchar(15) COLLATE SQL_Latin1_General_CP850_Bin,
    StreetNo nvarchar(25) COLLATE SQL_Latin1_General_CP850_Bin,
    Sangkat nvarchar(50) COLLATE SQL_Latin1_General_CP850_Bin,
    Khann nvarchar(50) COLLATE SQL_Latin1_General_CP850_Bin,
    Province nvarchar(50) COLLATE SQL_Latin1_General_CP850_Bin,
    ContactNumber nvarchar(20) COLLATE SQL_Latin1_General_CP850_Bin,
    PersonalNumber nvarchar(20) COLLATE SQL_Latin1_General_CP850_Bin,
    Salary money,
    HireDate date,
    Photo varbinary(max),
    StopWork bit
);
Go

CREATE TYPE BookDetailsType AS TABLE
(
    BookCode int,
    BookTitle nvarchar(255),
	BorrowDate date,
    DueDate date
);
Go

CREATE TYPE dbo.ReturnDetailType AS TABLE
(
	BorrowID int Not Null,
    BookCode int Not Null,
	BookTitle nvarchar(255) Not Null,
    BorrowDate date Not Null,
    DueDate date Not Null,
    Ripped bit Null,
    FineAmount money Null
);
GO

CREATE TYPE dbo.tbImportDetailType AS TABLE
(
    BookCode int Not Null,
    BookTitle nvarchar(255) Collate SQL_Latin1_General_CP850_Bin Not Null,
    ImportQty tinyint Null,
    UnitPrice money Null,
    Amount money Not Null
);
GO

