-- VIEWs
-- Create view for Book
CREATE VIEW vGetAllBooks
AS
SELECT * FROM tbBook;
GO

CREATE VIEW vGetBookTitle
AS
SELECT BookCode, BookTitle From tbBook;
Go

-- Create View for Member
CREATE VIEW vGetAllMembers
AS
SELECT * FROM tbMember;
GO

CREATE VIEW vGetMemberIDName
AS
SELECT MemberID, (FirstName + ' ' + LastName) AS MemberName From tbMember;
Go

-- Create View for Supplier
CREATE VIEW vGetAllSuppliers
AS
SELECT * FROM tbSupplier;
GO

CREATE VIEW vGetSuppliersName
AS
SELECT SupplierID, SupplierName FROM tbSupplier;
GO

-- Staff
CREATE VIEW vGetAllStaff
AS
SELECT * FROM tbStaff;
Go

CREATE VIEW vGetStaffIDNamePosition
AS
SELECT  StaffID, (FirstName + ' ' + LastName) AS StaffName, StaffPosition FROM tbStaff;
GO

CREATE VIEW vGetSalaryReport
AS
SELECT StaffID, (FirstName + ' ' + LastName) AS StaffName, StaffPosition, Salary, StopWork FROM tbStaff;
Go

SELECT CONVERT(VARCHAR, StaffID) AS StaffIDString, * FROM vGetStaffIDNamePosition
select * from vGetSalaryReport
-- User
CREATE VIEW vGetAllUser
AS
SELECT * FROM tbUser;
Go

CREATE VIEW vGetUserIDName
AS
SELECT UserID, UserName FROM tbUser;
GO

-- Card
CREATE VIEW vGetAllCard
AS
SELECT * FROM tbCard;
Go

CREATE VIEW vGetCardIDMemName
AS
SELECT CardID, MemberName FROM tbCard;
GO

-- Import
CREATE VIEW vGetAllImports
AS
SELECT * FROM tbImport;
GO

CREATE VIEW vGetImport
AS
SELECT ImportID, BookCode FROM tbImportDetail;
GO

-- ImportDetail
CREATE VIEW vImportDetails AS
SELECT i.ImportID, i.ImportDate, i.TotalAmount, i.SupplierID, i.SupplierName, i.StaffID, i.StaffName, i.StaffPosition, id.BookCode, id.BookTitle, id.UnitPrice, id.ImportQty, id.Amount
FROM tbImport i
JOIN tbImportDetail id ON i.ImportID = id.ImportID;
Go

CREATE VIEW vGetAllImportDetails
AS
SELECT * FROM tbImportDetail;
GO

CREATE VIEW vGetImportDetailIDBookTCode
AS
SELECT ImportID, BookCode FROM tbImportDetail;
GO
-- Borrow
 
-- BorrowDetail
CREATE VIEW vBorrowDetails AS
SELECT b.BorrowID, b.BorrowDate, b.MemberID, b.MemberName, b.StaffID, b.StaffName, b.StaffPosition, bd.BookCode, bd.BookTitle, bd.DueDate
FROM tbBorrow b
JOIN tbBorrowDetail bd ON b.BorrowID = bd.BorrowID;

CREATE VIEW vBorrowDetail AS
SELECT * FROM tbBorrowDetail;
Go


SELECT * FROM vBorrowDetails;
SELECT * FROM vGetStaffIDNamePosition

-- Return
-- ReturnDetail
CREATE VIEW vReturnDetails AS
SELECT r.ReturnID, r.ReturnDate, r.MemberID, r.MemberName, r.StaffID, r.StaffName, r.StaffPosition, rd.BorrowID, rd.BookCode, rd.BookTitle, rd.BorrowDate, rd.DueDate, rd.Ripped, rd.FineAmount
FROM tbReturn r
JOIN tbReturnDetail rd ON r.ReturnID = rd.ReturnID;
Go
select * from vReturnDetails
-- ReturnDetail
-- BorrowExpire
CREATE VIEW vBorrowExpire AS
SELECT 
    BorrowExpireID,
    ExpiredDate,
    BorrowID,
    MemberID,
    BookTitle
FROM 
    tbBorrowExpire;
GO
select * from vBorrowExpire
-- Invoice
-- Payment

-- Province
CREATE VIEW vGetProvinceName
AS
SELECT ProvinceCode, ProvinceName FROM tbProvince;
Go

-- District
CREATE VIEW vDistrictNameByProvinceID AS
SELECT D.DistrictCode, D.DistrictName, P.ProvinceCode
FROM tbDistrict D
INNER JOIN tbProvince P ON D.ProvinceCode = P.ProvinceCode;
Go

select * from vCommuneNameByDistrictID

-- Commune
CREATE VIEW vCommuneNameByDistrictID AS
SELECT C.CommuneCode, C.CommuneName, D.DistrictCode
FROM tbCommune C
INNER JOIN tbDistrict D ON C.DistrictCode = D.DistrictCode;
Go 

SELECT * FROM vGetMemberIDName
